Getting started with pysentiment2
**********************************

Install
=======

Install via::

    pip install pysentiment2

Usage
=========

Some highlighted functionality.

This is a simple example::

    import pysentiment2


