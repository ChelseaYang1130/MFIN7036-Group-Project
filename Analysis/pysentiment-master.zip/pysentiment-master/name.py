
if __name__ == '__main__':
    import conf
    print(conf.PACKAGE_NAME)
