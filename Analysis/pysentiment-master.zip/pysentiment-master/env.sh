#!/bin/bash
eval "$(python conf.py)";